﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Menu))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnEmpleado = New System.Windows.Forms.Button()
        Me.BtnPuestos = New System.Windows.Forms.Button()
        Me.BtnHorarios = New System.Windows.Forms.Button()
        Me.BtnSucursales = New System.Windows.Forms.Button()
        Me.BtnProveedores = New System.Windows.Forms.Button()
        Me.BtnTProveedor = New System.Windows.Forms.Button()
        Me.BtnClientes = New System.Windows.Forms.Button()
        Me.BtnClienteSuc = New System.Windows.Forms.Button()
        Me.BtnSurtido = New System.Windows.Forms.Button()
        Me.BtnFlores = New System.Windows.Forms.Button()
        Me.BtnTFlor = New System.Windows.Forms.Button()
        Me.BtnTemporadas = New System.Windows.Forms.Button()
        Me.BtnArreglos = New System.Windows.Forms.Button()
        Me.BtnFlorArreglo = New System.Windows.Forms.Button()
        Me.BtnTArreglo = New System.Windows.Forms.Button()
        Me.BtnTamArreglo = New System.Windows.Forms.Button()
        Me.BtnVenta = New System.Windows.Forms.Button()
        Me.BtnTVenta = New System.Windows.Forms.Button()
        Me.BtnTPago = New System.Windows.Forms.Button()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel1.Controls.Add(Me.pictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(-142, -2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(945, 49)
        Me.Panel1.TabIndex = 52
        '
        'BtnEmpleado
        '
        Me.BtnEmpleado.FlatAppearance.BorderSize = 0
        Me.BtnEmpleado.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnEmpleado.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEmpleado.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnEmpleado.Location = New System.Drawing.Point(49, 97)
        Me.BtnEmpleado.Name = "BtnEmpleado"
        Me.BtnEmpleado.Size = New System.Drawing.Size(127, 50)
        Me.BtnEmpleado.TabIndex = 53
        Me.BtnEmpleado.Text = "Empleados"
        Me.BtnEmpleado.UseVisualStyleBackColor = True
        '
        'BtnPuestos
        '
        Me.BtnPuestos.FlatAppearance.BorderSize = 0
        Me.BtnPuestos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnPuestos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPuestos.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPuestos.Location = New System.Drawing.Point(192, 97)
        Me.BtnPuestos.Name = "BtnPuestos"
        Me.BtnPuestos.Size = New System.Drawing.Size(127, 50)
        Me.BtnPuestos.TabIndex = 55
        Me.BtnPuestos.Text = "Puestos"
        Me.BtnPuestos.UseVisualStyleBackColor = True
        '
        'BtnHorarios
        '
        Me.BtnHorarios.FlatAppearance.BorderSize = 0
        Me.BtnHorarios.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnHorarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHorarios.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHorarios.Location = New System.Drawing.Point(336, 97)
        Me.BtnHorarios.Name = "BtnHorarios"
        Me.BtnHorarios.Size = New System.Drawing.Size(127, 50)
        Me.BtnHorarios.TabIndex = 56
        Me.BtnHorarios.Text = "Horarios"
        Me.BtnHorarios.UseVisualStyleBackColor = True
        '
        'BtnSucursales
        '
        Me.BtnSucursales.FlatAppearance.BorderSize = 0
        Me.BtnSucursales.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnSucursales.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSucursales.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSucursales.Location = New System.Drawing.Point(478, 97)
        Me.BtnSucursales.Name = "BtnSucursales"
        Me.BtnSucursales.Size = New System.Drawing.Size(127, 50)
        Me.BtnSucursales.TabIndex = 57
        Me.BtnSucursales.Text = "Sucursales"
        Me.BtnSucursales.UseVisualStyleBackColor = True
        '
        'BtnProveedores
        '
        Me.BtnProveedores.FlatAppearance.BorderSize = 0
        Me.BtnProveedores.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnProveedores.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnProveedores.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnProveedores.Location = New System.Drawing.Point(624, 97)
        Me.BtnProveedores.Name = "BtnProveedores"
        Me.BtnProveedores.Size = New System.Drawing.Size(127, 50)
        Me.BtnProveedores.TabIndex = 58
        Me.BtnProveedores.Text = "Proveedores"
        Me.BtnProveedores.UseVisualStyleBackColor = True
        '
        'BtnTProveedor
        '
        Me.BtnTProveedor.FlatAppearance.BorderSize = 0
        Me.BtnTProveedor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnTProveedor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTProveedor.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTProveedor.Location = New System.Drawing.Point(49, 170)
        Me.BtnTProveedor.Name = "BtnTProveedor"
        Me.BtnTProveedor.Size = New System.Drawing.Size(127, 68)
        Me.BtnTProveedor.TabIndex = 59
        Me.BtnTProveedor.Text = "Tipo proveedor"
        Me.BtnTProveedor.UseVisualStyleBackColor = True
        '
        'BtnClientes
        '
        Me.BtnClientes.FlatAppearance.BorderSize = 0
        Me.BtnClientes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnClientes.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClientes.Location = New System.Drawing.Point(336, 170)
        Me.BtnClientes.Name = "BtnClientes"
        Me.BtnClientes.Size = New System.Drawing.Size(127, 68)
        Me.BtnClientes.TabIndex = 60
        Me.BtnClientes.Text = "Clientes"
        Me.BtnClientes.UseVisualStyleBackColor = True
        '
        'BtnClienteSuc
        '
        Me.BtnClienteSuc.FlatAppearance.BorderSize = 0
        Me.BtnClienteSuc.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnClienteSuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnClienteSuc.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClienteSuc.Location = New System.Drawing.Point(478, 170)
        Me.BtnClienteSuc.Name = "BtnClienteSuc"
        Me.BtnClienteSuc.Size = New System.Drawing.Size(127, 68)
        Me.BtnClienteSuc.TabIndex = 61
        Me.BtnClienteSuc.Text = "Cliente por sucursal"
        Me.BtnClienteSuc.UseVisualStyleBackColor = True
        '
        'BtnSurtido
        '
        Me.BtnSurtido.FlatAppearance.BorderSize = 0
        Me.BtnSurtido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnSurtido.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSurtido.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSurtido.Location = New System.Drawing.Point(192, 170)
        Me.BtnSurtido.Name = "BtnSurtido"
        Me.BtnSurtido.Size = New System.Drawing.Size(127, 68)
        Me.BtnSurtido.TabIndex = 62
        Me.BtnSurtido.Text = "Surtido"
        Me.BtnSurtido.UseVisualStyleBackColor = True
        '
        'BtnFlores
        '
        Me.BtnFlores.FlatAppearance.BorderSize = 0
        Me.BtnFlores.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnFlores.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFlores.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFlores.Location = New System.Drawing.Point(624, 170)
        Me.BtnFlores.Name = "BtnFlores"
        Me.BtnFlores.Size = New System.Drawing.Size(127, 68)
        Me.BtnFlores.TabIndex = 63
        Me.BtnFlores.Text = "Flores"
        Me.BtnFlores.UseVisualStyleBackColor = True
        '
        'BtnTFlor
        '
        Me.BtnTFlor.FlatAppearance.BorderSize = 0
        Me.BtnTFlor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnTFlor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTFlor.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTFlor.Location = New System.Drawing.Point(49, 258)
        Me.BtnTFlor.Name = "BtnTFlor"
        Me.BtnTFlor.Size = New System.Drawing.Size(127, 68)
        Me.BtnTFlor.TabIndex = 64
        Me.BtnTFlor.Text = "Tipo flor"
        Me.BtnTFlor.UseVisualStyleBackColor = True
        '
        'BtnTemporadas
        '
        Me.BtnTemporadas.FlatAppearance.BorderSize = 0
        Me.BtnTemporadas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnTemporadas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTemporadas.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTemporadas.Location = New System.Drawing.Point(192, 258)
        Me.BtnTemporadas.Name = "BtnTemporadas"
        Me.BtnTemporadas.Size = New System.Drawing.Size(127, 68)
        Me.BtnTemporadas.TabIndex = 65
        Me.BtnTemporadas.Text = "Temporada de flores"
        Me.BtnTemporadas.UseVisualStyleBackColor = True
        '
        'BtnArreglos
        '
        Me.BtnArreglos.FlatAppearance.BorderSize = 0
        Me.BtnArreglos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnArreglos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnArreglos.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnArreglos.Location = New System.Drawing.Point(333, 259)
        Me.BtnArreglos.Name = "BtnArreglos"
        Me.BtnArreglos.Size = New System.Drawing.Size(127, 68)
        Me.BtnArreglos.TabIndex = 66
        Me.BtnArreglos.Text = "Arreglos"
        Me.BtnArreglos.UseVisualStyleBackColor = True
        '
        'BtnFlorArreglo
        '
        Me.BtnFlorArreglo.FlatAppearance.BorderSize = 0
        Me.BtnFlorArreglo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnFlorArreglo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnFlorArreglo.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFlorArreglo.Location = New System.Drawing.Point(478, 259)
        Me.BtnFlorArreglo.Name = "BtnFlorArreglo"
        Me.BtnFlorArreglo.Size = New System.Drawing.Size(127, 68)
        Me.BtnFlorArreglo.TabIndex = 67
        Me.BtnFlorArreglo.Text = "Flores por arreglo"
        Me.BtnFlorArreglo.UseVisualStyleBackColor = True
        '
        'BtnTArreglo
        '
        Me.BtnTArreglo.FlatAppearance.BorderSize = 0
        Me.BtnTArreglo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnTArreglo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTArreglo.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTArreglo.Location = New System.Drawing.Point(624, 259)
        Me.BtnTArreglo.Name = "BtnTArreglo"
        Me.BtnTArreglo.Size = New System.Drawing.Size(127, 68)
        Me.BtnTArreglo.TabIndex = 68
        Me.BtnTArreglo.Text = "Tipos de arreglo"
        Me.BtnTArreglo.UseVisualStyleBackColor = True
        '
        'BtnTamArreglo
        '
        Me.BtnTamArreglo.FlatAppearance.BorderSize = 0
        Me.BtnTamArreglo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnTamArreglo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTamArreglo.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTamArreglo.Location = New System.Drawing.Point(49, 347)
        Me.BtnTamArreglo.Name = "BtnTamArreglo"
        Me.BtnTamArreglo.Size = New System.Drawing.Size(127, 68)
        Me.BtnTamArreglo.TabIndex = 69
        Me.BtnTamArreglo.Text = "Tamaños de arreglo"
        Me.BtnTamArreglo.UseVisualStyleBackColor = True
        '
        'BtnVenta
        '
        Me.BtnVenta.FlatAppearance.BorderSize = 0
        Me.BtnVenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnVenta.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnVenta.Location = New System.Drawing.Point(192, 347)
        Me.BtnVenta.Name = "BtnVenta"
        Me.BtnVenta.Size = New System.Drawing.Size(127, 68)
        Me.BtnVenta.TabIndex = 70
        Me.BtnVenta.Text = "Venta / Detalle "
        Me.BtnVenta.UseVisualStyleBackColor = True
        '
        'BtnTVenta
        '
        Me.BtnTVenta.FlatAppearance.BorderSize = 0
        Me.BtnTVenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnTVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTVenta.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTVenta.Location = New System.Drawing.Point(336, 347)
        Me.BtnTVenta.Name = "BtnTVenta"
        Me.BtnTVenta.Size = New System.Drawing.Size(127, 68)
        Me.BtnTVenta.TabIndex = 72
        Me.BtnTVenta.Text = "Tipos de venta"
        Me.BtnTVenta.UseVisualStyleBackColor = True
        '
        'BtnTPago
        '
        Me.BtnTPago.FlatAppearance.BorderSize = 0
        Me.BtnTPago.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.BtnTPago.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTPago.Font = New System.Drawing.Font("Typewriter_Condensed_Demi", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTPago.Location = New System.Drawing.Point(478, 347)
        Me.BtnTPago.Name = "BtnTPago"
        Me.BtnTPago.Size = New System.Drawing.Size(127, 68)
        Me.BtnTPago.TabIndex = 73
        Me.BtnTPago.Text = "Tipos de pagos"
        Me.BtnTPago.UseVisualStyleBackColor = True
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Image)
        Me.pictureBox1.Location = New System.Drawing.Point(881, 3)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(61, 49)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox1.TabIndex = 74
        Me.pictureBox1.TabStop = False
        '
        'Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(800, 470)
        Me.Controls.Add(Me.BtnTPago)
        Me.Controls.Add(Me.BtnTVenta)
        Me.Controls.Add(Me.BtnVenta)
        Me.Controls.Add(Me.BtnTamArreglo)
        Me.Controls.Add(Me.BtnTArreglo)
        Me.Controls.Add(Me.BtnFlorArreglo)
        Me.Controls.Add(Me.BtnArreglos)
        Me.Controls.Add(Me.BtnTemporadas)
        Me.Controls.Add(Me.BtnTFlor)
        Me.Controls.Add(Me.BtnFlores)
        Me.Controls.Add(Me.BtnSurtido)
        Me.Controls.Add(Me.BtnClienteSuc)
        Me.Controls.Add(Me.BtnClientes)
        Me.Controls.Add(Me.BtnTProveedor)
        Me.Controls.Add(Me.BtnProveedores)
        Me.Controls.Add(Me.BtnSucursales)
        Me.Controls.Add(Me.BtnHorarios)
        Me.Controls.Add(Me.BtnPuestos)
        Me.Controls.Add(Me.BtnEmpleado)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Menu"
        Me.Text = "Menu"
        Me.Panel1.ResumeLayout(False)
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnEmpleado As Button
    Friend WithEvents BtnPuestos As Button
    Friend WithEvents BtnHorarios As Button
    Friend WithEvents BtnSucursales As Button
    Friend WithEvents BtnProveedores As Button
    Friend WithEvents BtnTProveedor As Button
    Friend WithEvents BtnClientes As Button
    Friend WithEvents BtnClienteSuc As Button
    Friend WithEvents BtnSurtido As Button
    Friend WithEvents BtnFlores As Button
    Friend WithEvents BtnTFlor As Button
    Friend WithEvents BtnTemporadas As Button
    Friend WithEvents BtnArreglos As Button
    Friend WithEvents BtnFlorArreglo As Button
    Friend WithEvents BtnTArreglo As Button
    Friend WithEvents BtnTamArreglo As Button
    Friend WithEvents BtnVenta As Button
    Friend WithEvents BtnTVenta As Button
    Friend WithEvents BtnTPago As Button
    Private WithEvents pictureBox1 As PictureBox
End Class
