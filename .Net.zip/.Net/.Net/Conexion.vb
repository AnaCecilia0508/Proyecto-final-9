﻿Module Conexion
    Public conexionn As New SqlClient.SqlConnection("data source=LENOVO20\SQLEXPRESS; initial catalog =Floreria20; integrated security=SSPI; persist security info = false; trusted_connection = yes; ")
End Module
