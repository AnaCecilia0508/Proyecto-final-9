﻿namespace PFR2_Floreria
{
    partial class Sucursal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sucursal));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtDireccion = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnEliminarSucursal = new System.Windows.Forms.Button();
            this.BtnActualizarSucursal = new System.Windows.Forms.Button();
            this.BtnAgregarSucursal = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(-21, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(824, 49);
            this.Panel1.TabIndex = 63;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(757, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 96;
            this.pictureBox1.TabStop = false;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.DataGridView1.Location = new System.Drawing.Point(18, 104);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(419, 211);
            this.DataGridView1.TabIndex = 62;
            // 
            // TxtDireccion
            // 
            this.TxtDireccion.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDireccion.Location = new System.Drawing.Point(453, 135);
            this.TxtDireccion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtDireccion.Name = "TxtDireccion";
            this.TxtDireccion.Size = new System.Drawing.Size(334, 31);
            this.TxtDireccion.TabIndex = 61;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(450, 105);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(77, 18);
            this.Label2.TabIndex = 60;
            this.Label2.Text = "Direccion";
            // 
            // BtnEliminarSucursal
            // 
            this.BtnEliminarSucursal.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarSucursal.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarSucursal.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarSucursal.Location = new System.Drawing.Point(693, 187);
            this.BtnEliminarSucursal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarSucursal.Name = "BtnEliminarSucursal";
            this.BtnEliminarSucursal.Size = new System.Drawing.Size(94, 43);
            this.BtnEliminarSucursal.TabIndex = 59;
            this.BtnEliminarSucursal.Text = "ELIMINAR";
            this.BtnEliminarSucursal.UseVisualStyleBackColor = false;
            this.BtnEliminarSucursal.Click += new System.EventHandler(this.BtnEliminarSucursal_Click);
            // 
            // BtnActualizarSucursal
            // 
            this.BtnActualizarSucursal.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarSucursal.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarSucursal.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarSucursal.Location = new System.Drawing.Point(565, 187);
            this.BtnActualizarSucursal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarSucursal.Name = "BtnActualizarSucursal";
            this.BtnActualizarSucursal.Size = new System.Drawing.Size(113, 43);
            this.BtnActualizarSucursal.TabIndex = 58;
            this.BtnActualizarSucursal.Text = "ACTUALIZAR";
            this.BtnActualizarSucursal.UseVisualStyleBackColor = false;
            this.BtnActualizarSucursal.Click += new System.EventHandler(this.BtnActualizarSucursal_Click);
            // 
            // BtnAgregarSucursal
            // 
            this.BtnAgregarSucursal.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarSucursal.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarSucursal.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarSucursal.Location = new System.Drawing.Point(453, 187);
            this.BtnAgregarSucursal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarSucursal.Name = "BtnAgregarSucursal";
            this.BtnAgregarSucursal.Size = new System.Drawing.Size(104, 43);
            this.BtnAgregarSucursal.TabIndex = 57;
            this.BtnAgregarSucursal.Text = "AGREGAR";
            this.BtnAgregarSucursal.UseVisualStyleBackColor = false;
            this.BtnAgregarSucursal.Click += new System.EventHandler(this.BtnAgregarSucursal_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(579, 63);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(99, 25);
            this.Label1.TabIndex = 56;
            this.Label1.Text = "SUCURSAL";
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(18, 55);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 64;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Sucursal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 345);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtDireccion);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BtnEliminarSucursal);
            this.Controls.Add(this.BtnActualizarSucursal);
            this.Controls.Add(this.BtnAgregarSucursal);
            this.Controls.Add(this.Label1);
            this.Name = "Sucursal";
            this.Text = "Sucursal";
            this.Load += new System.EventHandler(this.Sucursal_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtDireccion;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnEliminarSucursal;
        internal System.Windows.Forms.Button BtnActualizarSucursal;
        internal System.Windows.Forms.Button BtnAgregarSucursal;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}