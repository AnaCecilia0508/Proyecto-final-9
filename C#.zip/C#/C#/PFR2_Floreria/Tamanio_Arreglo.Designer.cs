﻿namespace PFR2_Floreria
{
    partial class Tamanio_Arreglo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tamanio_Arreglo));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtDescripcionTA = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnEliminarTA = new System.Windows.Forms.Button();
            this.BtnActualizarTA = new System.Windows.Forms.Button();
            this.BtnAgregarTA = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(-11, -1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(811, 49);
            this.Panel1.TabIndex = 63;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.DataGridView1.Location = new System.Drawing.Point(28, 102);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(386, 247);
            this.DataGridView1.TabIndex = 62;
            // 
            // TxtDescripcionTA
            // 
            this.TxtDescripcionTA.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescripcionTA.Location = new System.Drawing.Point(542, 124);
            this.TxtDescripcionTA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtDescripcionTA.Name = "TxtDescripcionTA";
            this.TxtDescripcionTA.Size = new System.Drawing.Size(244, 31);
            this.TxtDescripcionTA.TabIndex = 61;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(439, 137);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(94, 18);
            this.Label2.TabIndex = 60;
            this.Label2.Text = "Descripcion";
            // 
            // BtnEliminarTA
            // 
            this.BtnEliminarTA.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarTA.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarTA.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarTA.Location = new System.Drawing.Point(685, 207);
            this.BtnEliminarTA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarTA.Name = "BtnEliminarTA";
            this.BtnEliminarTA.Size = new System.Drawing.Size(101, 44);
            this.BtnEliminarTA.TabIndex = 59;
            this.BtnEliminarTA.Text = "ELIMINAR";
            this.BtnEliminarTA.UseVisualStyleBackColor = false;
            this.BtnEliminarTA.Click += new System.EventHandler(this.BtnEliminarTA_Click);
            // 
            // BtnActualizarTA
            // 
            this.BtnActualizarTA.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarTA.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarTA.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarTA.Location = new System.Drawing.Point(553, 207);
            this.BtnActualizarTA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarTA.Name = "BtnActualizarTA";
            this.BtnActualizarTA.Size = new System.Drawing.Size(108, 44);
            this.BtnActualizarTA.TabIndex = 58;
            this.BtnActualizarTA.Text = "ACTUALIZAR";
            this.BtnActualizarTA.UseVisualStyleBackColor = false;
            this.BtnActualizarTA.Click += new System.EventHandler(this.BtnActualizarTA_Click);
            // 
            // BtnAgregarTA
            // 
            this.BtnAgregarTA.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarTA.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarTA.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarTA.Location = new System.Drawing.Point(442, 207);
            this.BtnAgregarTA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarTA.Name = "BtnAgregarTA";
            this.BtnAgregarTA.Size = new System.Drawing.Size(95, 44);
            this.BtnAgregarTA.TabIndex = 57;
            this.BtnAgregarTA.Text = "AGREGAR";
            this.BtnAgregarTA.UseVisualStyleBackColor = false;
            this.BtnAgregarTA.Click += new System.EventHandler(this.BtnAgregarTA_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(531, 70);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(204, 25);
            this.Label1.TabIndex = 56;
            this.Label1.Text = "TAMAÑO  DE ARREGLOS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(748, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 96;
            this.pictureBox1.TabStop = false;
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(28, 53);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 64;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Tamanio_Arreglo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 373);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtDescripcionTA);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BtnEliminarTA);
            this.Controls.Add(this.BtnActualizarTA);
            this.Controls.Add(this.BtnAgregarTA);
            this.Controls.Add(this.Label1);
            this.Name = "Tamanio_Arreglo";
            this.Text = "Tamanio_Arreglo";
            this.Load += new System.EventHandler(this.Tamanio_Arreglo_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtDescripcionTA;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnEliminarTA;
        internal System.Windows.Forms.Button BtnActualizarTA;
        internal System.Windows.Forms.Button BtnAgregarTA;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}