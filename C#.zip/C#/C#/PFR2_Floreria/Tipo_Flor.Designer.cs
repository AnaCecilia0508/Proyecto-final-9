﻿namespace PFR2_Floreria
{
    partial class Tipo_Flor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipo_Flor));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtDescripcionTF = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnEliminarTF = new System.Windows.Forms.Button();
            this.BtnActualizarTF = new System.Windows.Forms.Button();
            this.BtnAgregarTF = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.BtnAgregarTFL = new System.Windows.Forms.Button();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(-5, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(805, 49);
            this.Panel1.TabIndex = 63;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(744, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 96;
            this.pictureBox1.TabStop = false;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Lucida Sans Unicode", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridView1.Location = new System.Drawing.Point(34, 104);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(392, 253);
            this.DataGridView1.TabIndex = 62;
            // 
            // TxtDescripcionTF
            // 
            this.TxtDescripcionTF.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescripcionTF.Location = new System.Drawing.Point(450, 152);
            this.TxtDescripcionTF.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtDescripcionTF.Name = "TxtDescripcionTF";
            this.TxtDescripcionTF.Size = new System.Drawing.Size(327, 31);
            this.TxtDescripcionTF.TabIndex = 61;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(447, 117);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(94, 18);
            this.Label2.TabIndex = 60;
            this.Label2.Text = "Descripcion";
            // 
            // BtnEliminarTF
            // 
            this.BtnEliminarTF.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarTF.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarTF.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarTF.Location = new System.Drawing.Point(684, 205);
            this.BtnEliminarTF.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarTF.Name = "BtnEliminarTF";
            this.BtnEliminarTF.Size = new System.Drawing.Size(93, 38);
            this.BtnEliminarTF.TabIndex = 59;
            this.BtnEliminarTF.Text = "ELIMINAR";
            this.BtnEliminarTF.UseVisualStyleBackColor = false;
            this.BtnEliminarTF.Click += new System.EventHandler(this.BtnEliminarTF_Click);
            // 
            // BtnActualizarTF
            // 
            this.BtnActualizarTF.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarTF.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarTF.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarTF.Location = new System.Drawing.Point(560, 205);
            this.BtnActualizarTF.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarTF.Name = "BtnActualizarTF";
            this.BtnActualizarTF.Size = new System.Drawing.Size(118, 38);
            this.BtnActualizarTF.TabIndex = 58;
            this.BtnActualizarTF.Text = "ACTUALIZAR";
            this.BtnActualizarTF.UseVisualStyleBackColor = false;
            this.BtnActualizarTF.Click += new System.EventHandler(this.BtnActualizarTF_Click);
            // 
            // BtnAgregarTF
            // 
            this.BtnAgregarTF.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarTF.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarTF.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarTF.Location = new System.Drawing.Point(269, 243);
            this.BtnAgregarTF.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarTF.Name = "BtnAgregarTF";
            this.BtnAgregarTF.Size = new System.Drawing.Size(104, 38);
            this.BtnAgregarTF.TabIndex = 57;
            this.BtnAgregarTF.Text = "AGREGAR";
            this.BtnAgregarTF.UseVisualStyleBackColor = false;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(555, 71);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(145, 25);
            this.Label1.TabIndex = 56;
            this.Label1.Text = "TIPOS DE FLORES";
            // 
            // BtnAgregarTFL
            // 
            this.BtnAgregarTFL.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarTFL.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarTFL.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarTFL.Location = new System.Drawing.Point(450, 205);
            this.BtnAgregarTFL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarTFL.Name = "BtnAgregarTFL";
            this.BtnAgregarTFL.Size = new System.Drawing.Size(95, 38);
            this.BtnAgregarTFL.TabIndex = 64;
            this.BtnAgregarTFL.Text = "AGREGAR";
            this.BtnAgregarTFL.UseVisualStyleBackColor = false;
            this.BtnAgregarTFL.Click += new System.EventHandler(this.BtnAgregarTFL_Click);
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(34, 54);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 97;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Tipo_Flor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 398);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.BtnAgregarTFL);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtDescripcionTF);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BtnEliminarTF);
            this.Controls.Add(this.BtnActualizarTF);
            this.Controls.Add(this.BtnAgregarTF);
            this.Controls.Add(this.Label1);
            this.Name = "Tipo_Flor";
            this.Text = "Tipo_Flor";
            this.Load += new System.EventHandler(this.Tipo_Flor_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtDescripcionTF;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnEliminarTF;
        internal System.Windows.Forms.Button BtnActualizarTF;
        internal System.Windows.Forms.Button BtnAgregarTF;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnAgregarTFL;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}