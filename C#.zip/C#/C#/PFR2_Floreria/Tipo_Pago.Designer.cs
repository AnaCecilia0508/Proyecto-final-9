﻿namespace PFR2_Floreria
{
    partial class Tipo_Pago
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipo_Pago));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtDescripcionTipoPago = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnEliminarTipoPago = new System.Windows.Forms.Button();
            this.BtnActualizarTipoPago = new System.Windows.Forms.Button();
            this.BtnAgregarTipoPago = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(-1, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(781, 49);
            this.Panel1.TabIndex = 63;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle6;
            this.DataGridView1.Location = new System.Drawing.Point(46, 102);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(363, 268);
            this.DataGridView1.TabIndex = 62;
            // 
            // TxtDescripcionTipoPago
            // 
            this.TxtDescripcionTipoPago.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescripcionTipoPago.Location = new System.Drawing.Point(434, 139);
            this.TxtDescripcionTipoPago.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtDescripcionTipoPago.Name = "TxtDescripcionTipoPago";
            this.TxtDescripcionTipoPago.Size = new System.Drawing.Size(332, 31);
            this.TxtDescripcionTipoPago.TabIndex = 61;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(431, 109);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(94, 18);
            this.Label2.TabIndex = 60;
            this.Label2.Text = "Descripcion";
            // 
            // BtnEliminarTipoPago
            // 
            this.BtnEliminarTipoPago.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarTipoPago.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarTipoPago.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarTipoPago.Location = new System.Drawing.Point(668, 194);
            this.BtnEliminarTipoPago.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarTipoPago.Name = "BtnEliminarTipoPago";
            this.BtnEliminarTipoPago.Size = new System.Drawing.Size(98, 41);
            this.BtnEliminarTipoPago.TabIndex = 59;
            this.BtnEliminarTipoPago.Text = "ELIMINAR";
            this.BtnEliminarTipoPago.UseVisualStyleBackColor = false;
            this.BtnEliminarTipoPago.Click += new System.EventHandler(this.BtnEliminarTipoPago_Click);
            // 
            // BtnActualizarTipoPago
            // 
            this.BtnActualizarTipoPago.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarTipoPago.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarTipoPago.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarTipoPago.Location = new System.Drawing.Point(536, 194);
            this.BtnActualizarTipoPago.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarTipoPago.Name = "BtnActualizarTipoPago";
            this.BtnActualizarTipoPago.Size = new System.Drawing.Size(115, 41);
            this.BtnActualizarTipoPago.TabIndex = 58;
            this.BtnActualizarTipoPago.Text = "ACTUALIZAR";
            this.BtnActualizarTipoPago.UseVisualStyleBackColor = false;
            this.BtnActualizarTipoPago.Click += new System.EventHandler(this.BtnActualizarTipoPago_Click);
            // 
            // BtnAgregarTipoPago
            // 
            this.BtnAgregarTipoPago.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarTipoPago.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarTipoPago.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarTipoPago.Location = new System.Drawing.Point(434, 194);
            this.BtnAgregarTipoPago.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarTipoPago.Name = "BtnAgregarTipoPago";
            this.BtnAgregarTipoPago.Size = new System.Drawing.Size(91, 41);
            this.BtnAgregarTipoPago.TabIndex = 57;
            this.BtnAgregarTipoPago.Text = "AGREGAR";
            this.BtnAgregarTipoPago.UseVisualStyleBackColor = false;
            this.BtnAgregarTipoPago.Click += new System.EventHandler(this.BtnAgregarTipoPago_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(547, 69);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(130, 25);
            this.Label1.TabIndex = 56;
            this.Label1.Text = "TIPOS DE PAGO";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(720, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 97;
            this.pictureBox1.TabStop = false;
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(46, 53);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 64;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Tipo_Pago
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(778, 397);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtDescripcionTipoPago);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BtnEliminarTipoPago);
            this.Controls.Add(this.BtnActualizarTipoPago);
            this.Controls.Add(this.BtnAgregarTipoPago);
            this.Controls.Add(this.Label1);
            this.Name = "Tipo_Pago";
            this.Text = "Tipo_Pago";
            this.Load += new System.EventHandler(this.Tipo_Pago_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtDescripcionTipoPago;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnEliminarTipoPago;
        internal System.Windows.Forms.Button BtnActualizarTipoPago;
        internal System.Windows.Forms.Button BtnAgregarTipoPago;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}