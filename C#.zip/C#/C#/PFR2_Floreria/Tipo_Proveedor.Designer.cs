﻿namespace PFR2_Floreria
{
    partial class Tipo_Proveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipo_Proveedor));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtDescripcionTP = new System.Windows.Forms.TextBox();
            this.BtnEliminarTipoP = new System.Windows.Forms.Button();
            this.BtnActualizarTipoP = new System.Windows.Forms.Button();
            this.BtnAgregarTipoP = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(0, -1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(909, 49);
            this.Panel1.TabIndex = 63;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.DataGridView1.Location = new System.Drawing.Point(13, 95);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(483, 273);
            this.DataGridView1.TabIndex = 62;
            // 
            // TxtDescripcionTP
            // 
            this.TxtDescripcionTP.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescripcionTP.Location = new System.Drawing.Point(529, 136);
            this.TxtDescripcionTP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtDescripcionTP.Name = "TxtDescripcionTP";
            this.TxtDescripcionTP.Size = new System.Drawing.Size(365, 31);
            this.TxtDescripcionTP.TabIndex = 61;
            // 
            // BtnEliminarTipoP
            // 
            this.BtnEliminarTipoP.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarTipoP.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarTipoP.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarTipoP.Location = new System.Drawing.Point(795, 194);
            this.BtnEliminarTipoP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarTipoP.Name = "BtnEliminarTipoP";
            this.BtnEliminarTipoP.Size = new System.Drawing.Size(99, 42);
            this.BtnEliminarTipoP.TabIndex = 60;
            this.BtnEliminarTipoP.Text = "ELIMINAR";
            this.BtnEliminarTipoP.UseVisualStyleBackColor = false;
            this.BtnEliminarTipoP.Click += new System.EventHandler(this.BtnEliminarTipoP_Click);
            // 
            // BtnActualizarTipoP
            // 
            this.BtnActualizarTipoP.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarTipoP.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarTipoP.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarTipoP.Location = new System.Drawing.Point(647, 194);
            this.BtnActualizarTipoP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarTipoP.Name = "BtnActualizarTipoP";
            this.BtnActualizarTipoP.Size = new System.Drawing.Size(134, 40);
            this.BtnActualizarTipoP.TabIndex = 59;
            this.BtnActualizarTipoP.Text = "ACTUALIZAR";
            this.BtnActualizarTipoP.UseVisualStyleBackColor = false;
            this.BtnActualizarTipoP.Click += new System.EventHandler(this.BtnActualizarTipoP_Click);
            // 
            // BtnAgregarTipoP
            // 
            this.BtnAgregarTipoP.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarTipoP.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarTipoP.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarTipoP.Location = new System.Drawing.Point(529, 192);
            this.BtnAgregarTipoP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarTipoP.Name = "BtnAgregarTipoP";
            this.BtnAgregarTipoP.Size = new System.Drawing.Size(103, 42);
            this.BtnAgregarTipoP.TabIndex = 58;
            this.BtnAgregarTipoP.Text = "AGREGAR";
            this.BtnAgregarTipoP.UseVisualStyleBackColor = false;
            this.BtnAgregarTipoP.Click += new System.EventHandler(this.BtnAgregarTipoP_Click);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(526, 104);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(94, 18);
            this.Label2.TabIndex = 57;
            this.Label2.Text = "Descripcion";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(625, 63);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(181, 25);
            this.Label1.TabIndex = 56;
            this.Label1.Text = "TIPOS DE PROVEEDOR";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(845, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 97;
            this.pictureBox1.TabStop = false;
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(12, 49);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 64;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Tipo_Proveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(905, 393);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtDescripcionTP);
            this.Controls.Add(this.BtnEliminarTipoP);
            this.Controls.Add(this.BtnActualizarTipoP);
            this.Controls.Add(this.BtnAgregarTipoP);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Name = "Tipo_Proveedor";
            this.Text = "Tipo_Proveedor";
            this.Load += new System.EventHandler(this.Tipo_Proveedor_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtDescripcionTP;
        internal System.Windows.Forms.Button BtnEliminarTipoP;
        internal System.Windows.Forms.Button BtnActualizarTipoP;
        internal System.Windows.Forms.Button BtnAgregarTipoP;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}