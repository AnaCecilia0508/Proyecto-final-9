﻿namespace PFR2_Floreria
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.BtnTPago = new System.Windows.Forms.Button();
            this.BtnTVenta = new System.Windows.Forms.Button();
            this.BtnDVenta = new System.Windows.Forms.Button();
            this.BtnTamArreglo = new System.Windows.Forms.Button();
            this.BtnTArreglo = new System.Windows.Forms.Button();
            this.BtnFlorArreglo = new System.Windows.Forms.Button();
            this.BtnArreglos = new System.Windows.Forms.Button();
            this.BtnTemporadas = new System.Windows.Forms.Button();
            this.BtnTFlor = new System.Windows.Forms.Button();
            this.BtnFlores = new System.Windows.Forms.Button();
            this.BtnSurtido = new System.Windows.Forms.Button();
            this.BtnClienteSuc = new System.Windows.Forms.Button();
            this.BtnClientes = new System.Windows.Forms.Button();
            this.BtnTProveedor = new System.Windows.Forms.Button();
            this.BtnProveedores = new System.Windows.Forms.Button();
            this.BtnSucursales = new System.Windows.Forms.Button();
            this.BtnHorarios = new System.Windows.Forms.Button();
            this.BtnPuestos = new System.Windows.Forms.Button();
            this.BtnEmpleado = new System.Windows.Forms.Button();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnTPago
            // 
            this.BtnTPago.FlatAppearance.BorderSize = 0;
            this.BtnTPago.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnTPago.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTPago.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTPago.Location = new System.Drawing.Point(486, 348);
            this.BtnTPago.Name = "BtnTPago";
            this.BtnTPago.Size = new System.Drawing.Size(127, 68);
            this.BtnTPago.TabIndex = 94;
            this.BtnTPago.Text = "Tipos de pagos";
            this.BtnTPago.UseVisualStyleBackColor = true;
            this.BtnTPago.Click += new System.EventHandler(this.BtnTPago_Click);
            // 
            // BtnTVenta
            // 
            this.BtnTVenta.FlatAppearance.BorderSize = 0;
            this.BtnTVenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnTVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTVenta.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTVenta.Location = new System.Drawing.Point(344, 348);
            this.BtnTVenta.Name = "BtnTVenta";
            this.BtnTVenta.Size = new System.Drawing.Size(127, 68);
            this.BtnTVenta.TabIndex = 93;
            this.BtnTVenta.Text = "Tipos de venta";
            this.BtnTVenta.UseVisualStyleBackColor = true;
            this.BtnTVenta.Click += new System.EventHandler(this.BtnTVenta_Click);
            // 
            // BtnDVenta
            // 
            this.BtnDVenta.FlatAppearance.BorderSize = 0;
            this.BtnDVenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnDVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDVenta.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDVenta.Location = new System.Drawing.Point(200, 348);
            this.BtnDVenta.Name = "BtnDVenta";
            this.BtnDVenta.Size = new System.Drawing.Size(127, 68);
            this.BtnDVenta.TabIndex = 92;
            this.BtnDVenta.Text = "Detalle de venta";
            this.BtnDVenta.UseVisualStyleBackColor = true;
            this.BtnDVenta.Click += new System.EventHandler(this.BtnDVenta_Click);
            // 
            // BtnTamArreglo
            // 
            this.BtnTamArreglo.FlatAppearance.BorderSize = 0;
            this.BtnTamArreglo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnTamArreglo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTamArreglo.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTamArreglo.Location = new System.Drawing.Point(57, 348);
            this.BtnTamArreglo.Name = "BtnTamArreglo";
            this.BtnTamArreglo.Size = new System.Drawing.Size(127, 68);
            this.BtnTamArreglo.TabIndex = 90;
            this.BtnTamArreglo.Text = "Tamaños de arreglo";
            this.BtnTamArreglo.UseVisualStyleBackColor = true;
            this.BtnTamArreglo.Click += new System.EventHandler(this.BtnTamArreglo_Click);
            // 
            // BtnTArreglo
            // 
            this.BtnTArreglo.FlatAppearance.BorderSize = 0;
            this.BtnTArreglo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnTArreglo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTArreglo.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTArreglo.Location = new System.Drawing.Point(632, 260);
            this.BtnTArreglo.Name = "BtnTArreglo";
            this.BtnTArreglo.Size = new System.Drawing.Size(127, 68);
            this.BtnTArreglo.TabIndex = 89;
            this.BtnTArreglo.Text = "Tipos de arreglo";
            this.BtnTArreglo.UseVisualStyleBackColor = true;
            this.BtnTArreglo.Click += new System.EventHandler(this.BtnTArreglo_Click);
            // 
            // BtnFlorArreglo
            // 
            this.BtnFlorArreglo.FlatAppearance.BorderSize = 0;
            this.BtnFlorArreglo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnFlorArreglo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFlorArreglo.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFlorArreglo.Location = new System.Drawing.Point(486, 260);
            this.BtnFlorArreglo.Name = "BtnFlorArreglo";
            this.BtnFlorArreglo.Size = new System.Drawing.Size(127, 68);
            this.BtnFlorArreglo.TabIndex = 88;
            this.BtnFlorArreglo.Text = "Flores por arreglo";
            this.BtnFlorArreglo.UseVisualStyleBackColor = true;
            this.BtnFlorArreglo.Click += new System.EventHandler(this.BtnFlorArreglo_Click);
            // 
            // BtnArreglos
            // 
            this.BtnArreglos.FlatAppearance.BorderSize = 0;
            this.BtnArreglos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnArreglos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnArreglos.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnArreglos.Location = new System.Drawing.Point(341, 260);
            this.BtnArreglos.Name = "BtnArreglos";
            this.BtnArreglos.Size = new System.Drawing.Size(127, 68);
            this.BtnArreglos.TabIndex = 87;
            this.BtnArreglos.Text = "Arreglos";
            this.BtnArreglos.UseVisualStyleBackColor = true;
            this.BtnArreglos.Click += new System.EventHandler(this.BtnArreglos_Click);
            // 
            // BtnTemporadas
            // 
            this.BtnTemporadas.FlatAppearance.BorderSize = 0;
            this.BtnTemporadas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnTemporadas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTemporadas.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTemporadas.Location = new System.Drawing.Point(200, 259);
            this.BtnTemporadas.Name = "BtnTemporadas";
            this.BtnTemporadas.Size = new System.Drawing.Size(127, 68);
            this.BtnTemporadas.TabIndex = 86;
            this.BtnTemporadas.Text = "Temporada de flores";
            this.BtnTemporadas.UseVisualStyleBackColor = true;
            this.BtnTemporadas.Click += new System.EventHandler(this.BtnTemporadas_Click);
            // 
            // BtnTFlor
            // 
            this.BtnTFlor.FlatAppearance.BorderSize = 0;
            this.BtnTFlor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnTFlor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTFlor.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTFlor.Location = new System.Drawing.Point(57, 259);
            this.BtnTFlor.Name = "BtnTFlor";
            this.BtnTFlor.Size = new System.Drawing.Size(127, 68);
            this.BtnTFlor.TabIndex = 85;
            this.BtnTFlor.Text = "Tipo flor";
            this.BtnTFlor.UseVisualStyleBackColor = true;
            this.BtnTFlor.Click += new System.EventHandler(this.BtnTFlor_Click);
            // 
            // BtnFlores
            // 
            this.BtnFlores.FlatAppearance.BorderSize = 0;
            this.BtnFlores.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnFlores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFlores.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFlores.Location = new System.Drawing.Point(632, 171);
            this.BtnFlores.Name = "BtnFlores";
            this.BtnFlores.Size = new System.Drawing.Size(127, 68);
            this.BtnFlores.TabIndex = 84;
            this.BtnFlores.Text = "Flores";
            this.BtnFlores.UseVisualStyleBackColor = true;
            this.BtnFlores.Click += new System.EventHandler(this.BtnFlores_Click);
            // 
            // BtnSurtido
            // 
            this.BtnSurtido.FlatAppearance.BorderSize = 0;
            this.BtnSurtido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnSurtido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSurtido.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSurtido.Location = new System.Drawing.Point(200, 171);
            this.BtnSurtido.Name = "BtnSurtido";
            this.BtnSurtido.Size = new System.Drawing.Size(127, 68);
            this.BtnSurtido.TabIndex = 83;
            this.BtnSurtido.Text = "Surtido";
            this.BtnSurtido.UseVisualStyleBackColor = true;
            this.BtnSurtido.Click += new System.EventHandler(this.BtnSurtido_Click);
            // 
            // BtnClienteSuc
            // 
            this.BtnClienteSuc.FlatAppearance.BorderSize = 0;
            this.BtnClienteSuc.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnClienteSuc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClienteSuc.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClienteSuc.Location = new System.Drawing.Point(486, 171);
            this.BtnClienteSuc.Name = "BtnClienteSuc";
            this.BtnClienteSuc.Size = new System.Drawing.Size(127, 68);
            this.BtnClienteSuc.TabIndex = 82;
            this.BtnClienteSuc.Text = "Cliente por sucursal";
            this.BtnClienteSuc.UseVisualStyleBackColor = true;
            this.BtnClienteSuc.Click += new System.EventHandler(this.BtnClienteSuc_Click);
            // 
            // BtnClientes
            // 
            this.BtnClientes.FlatAppearance.BorderSize = 0;
            this.BtnClientes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClientes.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClientes.Location = new System.Drawing.Point(344, 171);
            this.BtnClientes.Name = "BtnClientes";
            this.BtnClientes.Size = new System.Drawing.Size(127, 68);
            this.BtnClientes.TabIndex = 81;
            this.BtnClientes.Text = "Clientes";
            this.BtnClientes.UseVisualStyleBackColor = true;
            this.BtnClientes.Click += new System.EventHandler(this.BtnClientes_Click);
            // 
            // BtnTProveedor
            // 
            this.BtnTProveedor.FlatAppearance.BorderSize = 0;
            this.BtnTProveedor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnTProveedor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTProveedor.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTProveedor.Location = new System.Drawing.Point(57, 171);
            this.BtnTProveedor.Name = "BtnTProveedor";
            this.BtnTProveedor.Size = new System.Drawing.Size(127, 68);
            this.BtnTProveedor.TabIndex = 80;
            this.BtnTProveedor.Text = "Tipo proveedor";
            this.BtnTProveedor.UseVisualStyleBackColor = true;
            this.BtnTProveedor.Click += new System.EventHandler(this.BtnTProveedor_Click);
            // 
            // BtnProveedores
            // 
            this.BtnProveedores.FlatAppearance.BorderSize = 0;
            this.BtnProveedores.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnProveedores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnProveedores.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnProveedores.Location = new System.Drawing.Point(632, 98);
            this.BtnProveedores.Name = "BtnProveedores";
            this.BtnProveedores.Size = new System.Drawing.Size(127, 50);
            this.BtnProveedores.TabIndex = 79;
            this.BtnProveedores.Text = "Proveedores";
            this.BtnProveedores.UseVisualStyleBackColor = true;
            this.BtnProveedores.Click += new System.EventHandler(this.BtnProveedores_Click);
            // 
            // BtnSucursales
            // 
            this.BtnSucursales.FlatAppearance.BorderSize = 0;
            this.BtnSucursales.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnSucursales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSucursales.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSucursales.Location = new System.Drawing.Point(486, 98);
            this.BtnSucursales.Name = "BtnSucursales";
            this.BtnSucursales.Size = new System.Drawing.Size(127, 50);
            this.BtnSucursales.TabIndex = 78;
            this.BtnSucursales.Text = "Sucursales";
            this.BtnSucursales.UseVisualStyleBackColor = true;
            this.BtnSucursales.Click += new System.EventHandler(this.BtnSucursales_Click);
            // 
            // BtnHorarios
            // 
            this.BtnHorarios.FlatAppearance.BorderSize = 0;
            this.BtnHorarios.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnHorarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnHorarios.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHorarios.Location = new System.Drawing.Point(344, 98);
            this.BtnHorarios.Name = "BtnHorarios";
            this.BtnHorarios.Size = new System.Drawing.Size(127, 50);
            this.BtnHorarios.TabIndex = 77;
            this.BtnHorarios.Text = "Horarios";
            this.BtnHorarios.UseVisualStyleBackColor = true;
            this.BtnHorarios.Click += new System.EventHandler(this.BtnHorarios_Click);
            // 
            // BtnPuestos
            // 
            this.BtnPuestos.FlatAppearance.BorderSize = 0;
            this.BtnPuestos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnPuestos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPuestos.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPuestos.Location = new System.Drawing.Point(200, 98);
            this.BtnPuestos.Name = "BtnPuestos";
            this.BtnPuestos.Size = new System.Drawing.Size(127, 50);
            this.BtnPuestos.TabIndex = 76;
            this.BtnPuestos.Text = "Puestos";
            this.BtnPuestos.UseVisualStyleBackColor = true;
            this.BtnPuestos.Click += new System.EventHandler(this.BtnPuestos_Click);
            // 
            // BtnEmpleado
            // 
            this.BtnEmpleado.FlatAppearance.BorderSize = 0;
            this.BtnEmpleado.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.BtnEmpleado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEmpleado.Font = new System.Drawing.Font("Typewriter_Condensed_Demi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEmpleado.Location = new System.Drawing.Point(57, 98);
            this.BtnEmpleado.Name = "BtnEmpleado";
            this.BtnEmpleado.Size = new System.Drawing.Size(127, 50);
            this.BtnEmpleado.TabIndex = 75;
            this.BtnEmpleado.Text = "Empleados";
            this.BtnEmpleado.UseVisualStyleBackColor = true;
            this.BtnEmpleado.Click += new System.EventHandler(this.BtnEmpleado_Click);
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(-134, -1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(945, 49);
            this.Panel1.TabIndex = 74;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(867, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 95;
            this.pictureBox1.TabStop = false;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnTPago);
            this.Controls.Add(this.BtnTVenta);
            this.Controls.Add(this.BtnDVenta);
            this.Controls.Add(this.BtnTamArreglo);
            this.Controls.Add(this.BtnTArreglo);
            this.Controls.Add(this.BtnFlorArreglo);
            this.Controls.Add(this.BtnArreglos);
            this.Controls.Add(this.BtnTemporadas);
            this.Controls.Add(this.BtnTFlor);
            this.Controls.Add(this.BtnFlores);
            this.Controls.Add(this.BtnSurtido);
            this.Controls.Add(this.BtnClienteSuc);
            this.Controls.Add(this.BtnClientes);
            this.Controls.Add(this.BtnTProveedor);
            this.Controls.Add(this.BtnProveedores);
            this.Controls.Add(this.BtnSucursales);
            this.Controls.Add(this.BtnHorarios);
            this.Controls.Add(this.BtnPuestos);
            this.Controls.Add(this.BtnEmpleado);
            this.Controls.Add(this.Panel1);
            this.Name = "Menu";
            this.Text = "Menu";
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button BtnTPago;
        internal System.Windows.Forms.Button BtnTVenta;
        internal System.Windows.Forms.Button BtnDVenta;
        internal System.Windows.Forms.Button BtnTamArreglo;
        internal System.Windows.Forms.Button BtnTArreglo;
        internal System.Windows.Forms.Button BtnFlorArreglo;
        internal System.Windows.Forms.Button BtnArreglos;
        internal System.Windows.Forms.Button BtnTemporadas;
        internal System.Windows.Forms.Button BtnTFlor;
        internal System.Windows.Forms.Button BtnFlores;
        internal System.Windows.Forms.Button BtnSurtido;
        internal System.Windows.Forms.Button BtnClienteSuc;
        internal System.Windows.Forms.Button BtnClientes;
        internal System.Windows.Forms.Button BtnTProveedor;
        internal System.Windows.Forms.Button BtnProveedores;
        internal System.Windows.Forms.Button BtnSucursales;
        internal System.Windows.Forms.Button BtnHorarios;
        internal System.Windows.Forms.Button BtnPuestos;
        internal System.Windows.Forms.Button BtnEmpleado;
        internal System.Windows.Forms.Panel Panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}