﻿namespace PFR2_Floreria
{
    partial class Tipo_Venta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipo_Venta));
            this.Panel1 = new System.Windows.Forms.Panel();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtDescripcionTipoVenta = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnEliminarTipoArreglo = new System.Windows.Forms.Button();
            this.BtnActualizarTipoArreglo = new System.Windows.Forms.Button();
            this.BtnAgregarTipoArreglo = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(0, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(840, 49);
            this.Panel1.TabIndex = 63;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.DataGridView1.Location = new System.Drawing.Point(39, 95);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(384, 226);
            this.DataGridView1.TabIndex = 62;
            // 
            // TxtDescripcionTipoVenta
            // 
            this.TxtDescripcionTipoVenta.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescripcionTipoVenta.Location = new System.Drawing.Point(456, 137);
            this.TxtDescripcionTipoVenta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtDescripcionTipoVenta.Name = "TxtDescripcionTipoVenta";
            this.TxtDescripcionTipoVenta.Size = new System.Drawing.Size(363, 31);
            this.TxtDescripcionTipoVenta.TabIndex = 61;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(453, 107);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(94, 18);
            this.Label2.TabIndex = 60;
            this.Label2.Text = "Descripcion";
            // 
            // BtnEliminarTipoArreglo
            // 
            this.BtnEliminarTipoArreglo.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarTipoArreglo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarTipoArreglo.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarTipoArreglo.Location = new System.Drawing.Point(722, 187);
            this.BtnEliminarTipoArreglo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarTipoArreglo.Name = "BtnEliminarTipoArreglo";
            this.BtnEliminarTipoArreglo.Size = new System.Drawing.Size(97, 42);
            this.BtnEliminarTipoArreglo.TabIndex = 59;
            this.BtnEliminarTipoArreglo.Text = "ELIMINAR";
            this.BtnEliminarTipoArreglo.UseVisualStyleBackColor = false;
            this.BtnEliminarTipoArreglo.Click += new System.EventHandler(this.BtnEliminarTipoArreglo_Click);
            // 
            // BtnActualizarTipoArreglo
            // 
            this.BtnActualizarTipoArreglo.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarTipoArreglo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarTipoArreglo.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarTipoArreglo.Location = new System.Drawing.Point(585, 187);
            this.BtnActualizarTipoArreglo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarTipoArreglo.Name = "BtnActualizarTipoArreglo";
            this.BtnActualizarTipoArreglo.Size = new System.Drawing.Size(119, 42);
            this.BtnActualizarTipoArreglo.TabIndex = 58;
            this.BtnActualizarTipoArreglo.Text = "ACTUALIZAR";
            this.BtnActualizarTipoArreglo.UseVisualStyleBackColor = false;
            this.BtnActualizarTipoArreglo.Click += new System.EventHandler(this.BtnActualizarTipoArreglo_Click);
            // 
            // BtnAgregarTipoArreglo
            // 
            this.BtnAgregarTipoArreglo.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarTipoArreglo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarTipoArreglo.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarTipoArreglo.Location = new System.Drawing.Point(456, 187);
            this.BtnAgregarTipoArreglo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarTipoArreglo.Name = "BtnAgregarTipoArreglo";
            this.BtnAgregarTipoArreglo.Size = new System.Drawing.Size(112, 42);
            this.BtnAgregarTipoArreglo.TabIndex = 57;
            this.BtnAgregarTipoArreglo.Text = "AGREGAR";
            this.BtnAgregarTipoArreglo.UseVisualStyleBackColor = false;
            this.BtnAgregarTipoArreglo.Click += new System.EventHandler(this.BtnAgregarTipoArreglo_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(580, 64);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(144, 25);
            this.Label1.TabIndex = 56;
            this.Label1.Text = "TIPOS DE VENTA";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(777, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 97;
            this.pictureBox1.TabStop = false;
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(39, 51);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 64;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Tipo_Venta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(839, 346);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtDescripcionTipoVenta);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BtnEliminarTipoArreglo);
            this.Controls.Add(this.BtnActualizarTipoArreglo);
            this.Controls.Add(this.BtnAgregarTipoArreglo);
            this.Controls.Add(this.Label1);
            this.Name = "Tipo_Venta";
            this.Text = "Tipo_Venta";
            this.Load += new System.EventHandler(this.Tipo_Venta_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtDescripcionTipoVenta;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnEliminarTipoArreglo;
        internal System.Windows.Forms.Button BtnActualizarTipoArreglo;
        internal System.Windows.Forms.Button BtnAgregarTipoArreglo;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}