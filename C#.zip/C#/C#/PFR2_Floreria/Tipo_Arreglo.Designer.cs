﻿namespace PFR2_Floreria
{
    partial class Tipo_Arreglo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tipo_Arreglo));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtDescripcionTipoArreglo = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnEliminarTipoArreglo = new System.Windows.Forms.Button();
            this.BtnActualizarTipoArreglo = new System.Windows.Forms.Button();
            this.BtnAgregarTipoArreglo = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(-1, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(801, 49);
            this.Panel1.TabIndex = 63;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(740, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 96;
            this.pictureBox1.TabStop = false;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridView1.Location = new System.Drawing.Point(37, 105);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(380, 270);
            this.DataGridView1.TabIndex = 62;
            // 
            // TxtDescripcionTipoArreglo
            // 
            this.TxtDescripcionTipoArreglo.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescripcionTipoArreglo.Location = new System.Drawing.Point(447, 133);
            this.TxtDescripcionTipoArreglo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtDescripcionTipoArreglo.Name = "TxtDescripcionTipoArreglo";
            this.TxtDescripcionTipoArreglo.Size = new System.Drawing.Size(344, 31);
            this.TxtDescripcionTipoArreglo.TabIndex = 61;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(444, 103);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(94, 18);
            this.Label2.TabIndex = 60;
            this.Label2.Text = "Descripcion";
            // 
            // BtnEliminarTipoArreglo
            // 
            this.BtnEliminarTipoArreglo.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarTipoArreglo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarTipoArreglo.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarTipoArreglo.Location = new System.Drawing.Point(688, 190);
            this.BtnEliminarTipoArreglo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarTipoArreglo.Name = "BtnEliminarTipoArreglo";
            this.BtnEliminarTipoArreglo.Size = new System.Drawing.Size(103, 43);
            this.BtnEliminarTipoArreglo.TabIndex = 59;
            this.BtnEliminarTipoArreglo.Text = "ELIMINAR";
            this.BtnEliminarTipoArreglo.UseVisualStyleBackColor = false;
            this.BtnEliminarTipoArreglo.Click += new System.EventHandler(this.BtnEliminarTipoArreglo_Click);
            // 
            // BtnActualizarTipoArreglo
            // 
            this.BtnActualizarTipoArreglo.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarTipoArreglo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarTipoArreglo.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarTipoArreglo.Location = new System.Drawing.Point(565, 190);
            this.BtnActualizarTipoArreglo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarTipoArreglo.Name = "BtnActualizarTipoArreglo";
            this.BtnActualizarTipoArreglo.Size = new System.Drawing.Size(110, 43);
            this.BtnActualizarTipoArreglo.TabIndex = 58;
            this.BtnActualizarTipoArreglo.Text = "ACTUALIZAR";
            this.BtnActualizarTipoArreglo.UseVisualStyleBackColor = false;
            this.BtnActualizarTipoArreglo.Click += new System.EventHandler(this.BtnActualizarTipoArreglo_Click);
            // 
            // BtnAgregarTipoArreglo
            // 
            this.BtnAgregarTipoArreglo.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarTipoArreglo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarTipoArreglo.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarTipoArreglo.Location = new System.Drawing.Point(447, 190);
            this.BtnAgregarTipoArreglo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarTipoArreglo.Name = "BtnAgregarTipoArreglo";
            this.BtnAgregarTipoArreglo.Size = new System.Drawing.Size(103, 43);
            this.BtnAgregarTipoArreglo.TabIndex = 57;
            this.BtnAgregarTipoArreglo.Text = "AGREGAR";
            this.BtnAgregarTipoArreglo.UseVisualStyleBackColor = false;
            this.BtnAgregarTipoArreglo.Click += new System.EventHandler(this.BtnAgregarTipoArreglo_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(544, 63);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(160, 25);
            this.Label1.TabIndex = 56;
            this.Label1.Text = "TIPOS DE ARREGLO";
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(36, 55);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 64;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Tipo_Arreglo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 396);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtDescripcionTipoArreglo);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BtnEliminarTipoArreglo);
            this.Controls.Add(this.BtnActualizarTipoArreglo);
            this.Controls.Add(this.BtnAgregarTipoArreglo);
            this.Controls.Add(this.Label1);
            this.Name = "Tipo_Arreglo";
            this.Text = "Tipo_Arreglo";
            this.Load += new System.EventHandler(this.Tipo_Arreglo_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtDescripcionTipoArreglo;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnEliminarTipoArreglo;
        internal System.Windows.Forms.Button BtnActualizarTipoArreglo;
        internal System.Windows.Forms.Button BtnAgregarTipoArreglo;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}