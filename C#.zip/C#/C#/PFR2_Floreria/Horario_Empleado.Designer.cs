﻿namespace PFR2_Floreria
{
    partial class Horario_Empleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Horario_Empleado));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtHrE = new System.Windows.Forms.TextBox();
            this.TxtHrS = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnEliminarHorario = new System.Windows.Forms.Button();
            this.BtnActualizarHorario = new System.Windows.Forms.Button();
            this.BtnAgregarHorario = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(-93, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(911, 49);
            this.Panel1.TabIndex = 64;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(829, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 70;
            this.pictureBox1.TabStop = false;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridView1.Location = new System.Drawing.Point(7, 108);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(401, 257);
            this.DataGridView1.TabIndex = 63;
            // 
            // TxtHrE
            // 
            this.TxtHrE.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHrE.Location = new System.Drawing.Point(594, 116);
            this.TxtHrE.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtHrE.Name = "TxtHrE";
            this.TxtHrE.Size = new System.Drawing.Size(195, 31);
            this.TxtHrE.TabIndex = 62;
            // 
            // TxtHrS
            // 
            this.TxtHrS.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHrS.Location = new System.Drawing.Point(594, 159);
            this.TxtHrS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtHrS.Name = "TxtHrS";
            this.TxtHrS.Size = new System.Drawing.Size(195, 31);
            this.TxtHrS.TabIndex = 61;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(455, 172);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(113, 18);
            this.Label3.TabIndex = 60;
            this.Label3.Text = "Hora de salida";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(455, 119);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(128, 18);
            this.Label2.TabIndex = 59;
            this.Label2.Text = "Hora de entrada";
            // 
            // BtnEliminarHorario
            // 
            this.BtnEliminarHorario.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarHorario.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarHorario.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarHorario.Location = new System.Drawing.Point(695, 222);
            this.BtnEliminarHorario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarHorario.Name = "BtnEliminarHorario";
            this.BtnEliminarHorario.Size = new System.Drawing.Size(100, 45);
            this.BtnEliminarHorario.TabIndex = 58;
            this.BtnEliminarHorario.Text = "ELIMINAR";
            this.BtnEliminarHorario.UseVisualStyleBackColor = false;
            this.BtnEliminarHorario.Click += new System.EventHandler(this.BtnEliminarHorario_Click);
            // 
            // BtnActualizarHorario
            // 
            this.BtnActualizarHorario.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarHorario.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarHorario.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarHorario.Location = new System.Drawing.Point(574, 223);
            this.BtnActualizarHorario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarHorario.Name = "BtnActualizarHorario";
            this.BtnActualizarHorario.Size = new System.Drawing.Size(115, 44);
            this.BtnActualizarHorario.TabIndex = 57;
            this.BtnActualizarHorario.Text = "ACTUALIZAR";
            this.BtnActualizarHorario.UseVisualStyleBackColor = false;
            this.BtnActualizarHorario.Click += new System.EventHandler(this.BtnActualizarHorario_Click);
            // 
            // BtnAgregarHorario
            // 
            this.BtnAgregarHorario.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarHorario.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarHorario.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarHorario.Location = new System.Drawing.Point(458, 222);
            this.BtnAgregarHorario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarHorario.Name = "BtnAgregarHorario";
            this.BtnAgregarHorario.Size = new System.Drawing.Size(110, 45);
            this.BtnAgregarHorario.TabIndex = 56;
            this.BtnAgregarHorario.Text = "AGREGAR";
            this.BtnAgregarHorario.UseVisualStyleBackColor = false;
            this.BtnAgregarHorario.Click += new System.EventHandler(this.BtnAgregarHorario_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(539, 69);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(175, 25);
            this.Label1.TabIndex = 55;
            this.Label1.Text = "HORARIO EMPLEADO";
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(7, 54);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 65;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Horario_Empleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 391);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtHrE);
            this.Controls.Add(this.TxtHrS);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BtnEliminarHorario);
            this.Controls.Add(this.BtnActualizarHorario);
            this.Controls.Add(this.BtnAgregarHorario);
            this.Controls.Add(this.Label1);
            this.Name = "Horario_Empleado";
            this.Text = "Horario_Empleado";
            this.Load += new System.EventHandler(this.Horario_Empleado_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtHrE;
        internal System.Windows.Forms.TextBox TxtHrS;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnEliminarHorario;
        internal System.Windows.Forms.Button BtnActualizarHorario;
        internal System.Windows.Forms.Button BtnAgregarHorario;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}