﻿namespace PFR2_Floreria
{
    partial class Cargo_Empleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cargo_Empleado));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.TxtSalario = new System.Windows.Forms.TextBox();
            this.TxtDescripcion = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnEliminarCargo = new System.Windows.Forms.Button();
            this.BtnActualizarCargo = new System.Windows.Forms.Button();
            this.BtnAgregarCargo = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.BtnRegresar = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Panel1.Controls.Add(this.pictureBox1);
            this.Panel1.Location = new System.Drawing.Point(-114, -1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(920, 49);
            this.Panel1.TabIndex = 63;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(849, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 68;
            this.pictureBox1.TabStop = false;
            // 
            // DataGridView1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridView1.Location = new System.Drawing.Point(14, 120);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.RowHeadersWidth = 51;
            this.DataGridView1.RowTemplate.Height = 24;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(420, 224);
            this.DataGridView1.TabIndex = 62;
            // 
            // TxtSalario
            // 
            this.TxtSalario.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSalario.Location = new System.Drawing.Point(567, 171);
            this.TxtSalario.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtSalario.Name = "TxtSalario";
            this.TxtSalario.Size = new System.Drawing.Size(217, 31);
            this.TxtSalario.TabIndex = 61;
            // 
            // TxtDescripcion
            // 
            this.TxtDescripcion.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescripcion.Location = new System.Drawing.Point(567, 120);
            this.TxtDescripcion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TxtDescripcion.Name = "TxtDescripcion";
            this.TxtDescripcion.Size = new System.Drawing.Size(217, 31);
            this.TxtDescripcion.TabIndex = 60;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(457, 184);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(56, 18);
            this.Label3.TabIndex = 59;
            this.Label3.Text = "Salario";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(457, 133);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(94, 18);
            this.Label2.TabIndex = 58;
            this.Label2.Text = "Descripcion";
            // 
            // BtnEliminarCargo
            // 
            this.BtnEliminarCargo.BackColor = System.Drawing.Color.Black;
            this.BtnEliminarCargo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEliminarCargo.ForeColor = System.Drawing.Color.White;
            this.BtnEliminarCargo.Location = new System.Drawing.Point(686, 241);
            this.BtnEliminarCargo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnEliminarCargo.Name = "BtnEliminarCargo";
            this.BtnEliminarCargo.Size = new System.Drawing.Size(98, 39);
            this.BtnEliminarCargo.TabIndex = 57;
            this.BtnEliminarCargo.Text = "ELIMINAR";
            this.BtnEliminarCargo.UseVisualStyleBackColor = false;
            this.BtnEliminarCargo.Click += new System.EventHandler(this.BtnEliminarCargo_Click);
            // 
            // BtnActualizarCargo
            // 
            this.BtnActualizarCargo.BackColor = System.Drawing.Color.Black;
            this.BtnActualizarCargo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnActualizarCargo.ForeColor = System.Drawing.Color.White;
            this.BtnActualizarCargo.Location = new System.Drawing.Point(557, 241);
            this.BtnActualizarCargo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnActualizarCargo.Name = "BtnActualizarCargo";
            this.BtnActualizarCargo.Size = new System.Drawing.Size(122, 41);
            this.BtnActualizarCargo.TabIndex = 56;
            this.BtnActualizarCargo.Text = "ACTUALIZAR";
            this.BtnActualizarCargo.UseVisualStyleBackColor = false;
            this.BtnActualizarCargo.Click += new System.EventHandler(this.BtnActualizarCargo_Click);
            // 
            // BtnAgregarCargo
            // 
            this.BtnAgregarCargo.BackColor = System.Drawing.Color.Black;
            this.BtnAgregarCargo.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAgregarCargo.ForeColor = System.Drawing.Color.White;
            this.BtnAgregarCargo.Location = new System.Drawing.Point(460, 241);
            this.BtnAgregarCargo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAgregarCargo.Name = "BtnAgregarCargo";
            this.BtnAgregarCargo.Size = new System.Drawing.Size(91, 41);
            this.BtnAgregarCargo.TabIndex = 55;
            this.BtnAgregarCargo.Text = "AGREGAR";
            this.BtnAgregarCargo.UseVisualStyleBackColor = false;
            this.BtnAgregarCargo.Click += new System.EventHandler(this.BtnAgregarCargo_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("212 Orion Sans", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(543, 76);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(167, 25);
            this.Label1.TabIndex = 54;
            this.Label1.Text = "PUESTO EMPLEADO";
            // 
            // BtnRegresar
            // 
            this.BtnRegresar.BackColor = System.Drawing.Color.Black;
            this.BtnRegresar.Font = new System.Drawing.Font("212 Orion Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRegresar.ForeColor = System.Drawing.Color.White;
            this.BtnRegresar.Location = new System.Drawing.Point(14, 60);
            this.BtnRegresar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnRegresar.Name = "BtnRegresar";
            this.BtnRegresar.Size = new System.Drawing.Size(102, 41);
            this.BtnRegresar.TabIndex = 64;
            this.BtnRegresar.Text = "REGRESAR";
            this.BtnRegresar.UseVisualStyleBackColor = false;
            this.BtnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);
            // 
            // Cargo_Empleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 377);
            this.Controls.Add(this.BtnRegresar);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.DataGridView1);
            this.Controls.Add(this.TxtSalario);
            this.Controls.Add(this.TxtDescripcion);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BtnEliminarCargo);
            this.Controls.Add(this.BtnActualizarCargo);
            this.Controls.Add(this.BtnAgregarCargo);
            this.Controls.Add(this.Label1);
            this.Name = "Cargo_Empleado";
            this.Text = "Cargo_Empleado";
            this.Load += new System.EventHandler(this.Cargo_Empleado_Load);
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.TextBox TxtSalario;
        internal System.Windows.Forms.TextBox TxtDescripcion;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnEliminarCargo;
        internal System.Windows.Forms.Button BtnActualizarCargo;
        internal System.Windows.Forms.Button BtnAgregarCargo;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button BtnRegresar;
    }
}